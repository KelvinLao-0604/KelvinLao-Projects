from datetime import datetime
import json
import re
from urllib import response
from flask import Response, request
from models import post
from models.following import Following
from views import can_view_post
from models import Bookmark
from models import Post
from models import LikePost
from models import Comment as Coment

# Bookmarks
def handle_db_insert_error(endpoint_function):
    def outer_function(self, *args, **kwargs):
        print('handle_db_insert_error')
        try:
            # try to execute the query:
            return endpoint_function(self, *args, **kwargs)
        except:
            import sys
            db_message = str(sys.exc_info()[1]) # stores DB error message
            print(db_message)                   # logs it to the console
            message = 'DECORATOR! Database Insert error. Make sure your post data is valid.'
            post_data = request.get_json()
            #post_data['user_id'] = self.current_user.id
            response_obj = {
                'message': message, 
                'db_message': db_message,
                'post_data': post_data
            }
            return Response(json.dumps(response_obj), mimetype="application/json", status=400)
    return outer_function


def is_valid_int(endpoint_function):
    def outer_function_with_security_checks(self):
        try:
            body = request.get_json()
            post_id = body.get('post_id')
            post_id = int(post_id)
        except:
            response_obj = {
                'message': 'Invalid post_id={0}'.format(post_id)
            }
            return Response(json.dumps(response_obj), mimetype="application/json", status=400)
        return endpoint_function(self)
    return outer_function_with_security_checks

def secure_bookmark(endpoint_function):
    def outer_function_with_security_checks(self):
        print('secure_bookmark')
        body = request.get_json()
        post_id = body.get('post_id')
        print(post_id)
        print(can_view_post(post_id, self.current_user))
        if can_view_post(post_id, self.current_user):
            return endpoint_function(self)
        else:
            response_obj = {
                'message': 'You don\'t have access to post_id={0}'.format(post_id)
            }
            return Response(json.dumps(response_obj), mimetype="application/json", status=404)
            
    return outer_function_with_security_checks


def check_ownership_of_bookmark(endpoint_function):
    def outer_function_with_security_checks(self, id):
        print(id)
        bookmark = Bookmark.query.get(id)
        if bookmark.user_id == self.current_user.id:
            return endpoint_function(self, id)
        else:
            response_obj = {
                'message': 'You did not create bookmark id={0}'.format(id)
            }
            return Response(json.dumps(response_obj), mimetype="application/json", status=404)
            
    return outer_function_with_security_checks

def is_valid_id(endpoint_function):
    def outer_function_with_security_checks(self):
        body = request.get_json()
        post_id = body.get('post_id')
        post = Post.query.get(post_id)
        if post == None:
            response_obj = {
                'message': 'Invalid post_id={0}'.format(post_id)
            }
            return Response(json.dumps(response_obj), mimetype="application/json", status=404)
        else:            
            return endpoint_function(self)
    return outer_function_with_security_checks

def is_valid_int_delete(endpoint_function):
    def outer_function_with_security_checks(self,id):
        try:
            test = int(id)
            return endpoint_function(self, id)
        except:
            int_response_obj = {
                'message': 'Not a valid int:{0}'.format(id)
            }
            return Response(json.dumps(int_response_obj), mimetype="application/json", status=400)       
    
    return outer_function_with_security_checks

def is_valid_id_delete(endpoint_function):
    def outer_function_with_security_checks(self,id):
        bookmark = Bookmark.query.get(id)
        if bookmark == None:
            response_obj = {
                'message': 'Invalid post_id={0}'.format(id)
            }
            return Response(json.dumps(response_obj), mimetype="application/json", status=404)
        else:            
            return endpoint_function(self,id)
    return outer_function_with_security_checks

# Posts
def check_if_empty(endpoint_function):
    def outer_function_with_security_checks(self):
        body = request.get_json()
        if body == {}:
            response_obj = {'message': 'Empty json'}
            return Response(json.dumps(response_obj), mimetype="application/json", status=400)
        else:
            return endpoint_function(self)
    return outer_function_with_security_checks

#Comments
def check_if_empty_comment(endpoint_function):
    def outer_function_with_security_checks(self):
        body = request.get_json()
        try: 
            post_id = body.get('post_id')
            text = body.get('text')
            return endpoint_function(self)
        except:
            response_obj = {'message': 'Missing parameters'}
            return Response(json.dumps(response_obj), mimetype="application/json", status=400)
    return outer_function_with_security_checks

def check_ownership_of_comment(endpoint_function):
    def outer_function_with_security_checks(self, id):
        comment = Coment.query.get(id)
        if comment.user_id == self.current_user.id:
            return endpoint_function(self, id)
        else:
            response_obj = {
                'message': 'You did not create comment id={0}'.format(id)
            }
            return Response(json.dumps(response_obj), mimetype="application/json", status=404)
            
    return outer_function_with_security_checks

#post_likes

def is_valid_id_like_post(endpoint_function):
    def outer_function_with_security_checks(self,post_id):
        post = Post.query.get(post_id)
        if post == None:
            response_obj = {
                'message': 'Invalid post_id={0}'.format(post_id)
            }
            return Response(json.dumps(response_obj), mimetype="application/json", status=404)
        else:            
            return endpoint_function(self,post_id)
    return outer_function_with_security_checks

def is_valid_int_like_post(endpoint_function):
    def outer_function_with_security_checks(self,post_id,id):
        print('testing for valid int')
        try:
            test = int(id)
            print(id)
            return endpoint_function(self, post_id, id)
        except:
            int_response_obj = {
                'message': 'Not a valid int:{0}'.format(id)
            }
            return Response(json.dumps(int_response_obj), mimetype="application/json", status=400)       
    
    return outer_function_with_security_checks

def is_valid_id_like_post_delete(endpoint_function):
    def outer_function_with_security_checks(self,post_id,id):
        print('testing for valid id')
        like = LikePost.query.get(id)
        if like == None:
            response_obj = {
                'message': 'Invalid post_id={0}'.format(id)
            }
            return Response(json.dumps(response_obj), mimetype="application/json", status=404)
        else:            
            return endpoint_function(self,post_id,id)
    return outer_function_with_security_checks

def secure_like_post(endpoint_function):
    def outer_function_with_security_checks(self,post_id):
        if can_view_post(post_id, self.current_user):
            return endpoint_function(self,post_id)
        else:
            response_obj = {
                'message': 'You don\'t have access to post_id={0}'.format(post_id)
            }
            return Response(json.dumps(response_obj), mimetype="application/json", status=404)
    return outer_function_with_security_checks

def handle_db_insert_error_like_post(endpoint_function):
    def outer_function(self, post_id, *args, **kwargs):
        print('handle_db_insert_error')
        try:
            # try to execute the query:
            return endpoint_function(self, post_id, *args, **kwargs)
        except:
            import sys
            db_message = str(sys.exc_info()[1]) # stores DB error message
            print(db_message)                   # logs it to the console
            message = 'DECORATOR! Database Insert error. Make sure your post data is valid.'
            post_data = request.get_json()
            #post_data['user_id'] = self.current_user.id
            response_obj = {
                'message': message, 
                'db_message': db_message,
                'post_data': post_data
            }
            return Response(json.dumps(response_obj), mimetype="application/json", status=400)
    return outer_function


def check_ownership_of_post(endpoint_function):
    def outer_function_with_security_checks(self, post_id, id):
        like = LikePost.query.get(id)
        if like.user_id == self.current_user.id:
            return endpoint_function(self, post_id, id)
        else:
            response_obj = {
                'message': 'You did not create bookmark id={0}'.format(id)
            }
            return Response(json.dumps(response_obj), mimetype="application/json", status=404)
            
    return outer_function_with_security_checks

#Following
def is_valid_id_follow(endpoint_function):
    def outer_function_with_security_checks(self):
        body = request.get_json()
        user_id = body.get('user_id')
        follow = Following.query.get(user_id)
        if follow == None:
            response_obj = {
                'message': 'Invalid post_id={0}'.format(user_id)
            }
            return Response(json.dumps(response_obj), mimetype="application/json", status=404)
        else:            
            return endpoint_function(self)
    return outer_function_with_security_checks

def is_valid_int_follow(endpoint_function):
    def outer_function_with_security_checks(self):
        try:
            body = request.get_json()
            user_id = body.get('user_id')
            user_id = int(user_id)
        except:
            response_obj = {
                'message': 'Invalid post_id={0}'.format(user_id)
            }
            return Response(json.dumps(response_obj), mimetype="application/json", status=400)
        return endpoint_function(self)
    return outer_function_with_security_checks

def check_ownership_of_follow(endpoint_function):
    def outer_function_with_security_checks(self, id):
        follow = Following.query.get(id)
        if follow.user_id == self.current_user.id:
            return endpoint_function(self, id)
        else:
            response_obj = {
                'message': 'You did not create bookmark id={0}'.format(id)
            }
            return Response(json.dumps(response_obj), mimetype="application/json", status=404)
            
    return outer_function_with_security_checks

def is_valid_id_delete_follow(endpoint_function):
    def outer_function_with_security_checks(self,id):
        follow = Following.query.get(id)
        if follow == None:
            response_obj = {
                'message': 'Invalid post_id={0}'.format(id)
            }
            return Response(json.dumps(response_obj), mimetype="application/json", status=404)
        else:            
            return endpoint_function(self,id)
    return outer_function_with_security_checks