from flask import Response, request
from flask_restful import Resource
import jwt
from decorators import jwt_or_login
from models import Bookmark, bookmark, db
import json
from . import can_view_post
from models import Post
import flask_jwt_extended  
from my_decorators import is_valid_id_delete, secure_bookmark, \
    handle_db_insert_error, check_ownership_of_bookmark, is_valid_int, is_valid_id, is_valid_int_delete, is_valid_id_delete

class BookmarksListEndpoint(Resource):

    def __init__(self, current_user):
        self.current_user = current_user
    
    @flask_jwt_extended.jwt_required()
    def get(self):
        bookmarks = Bookmark.query.filter_by(
            user_id = self.current_user.id).order_by('id').all()
        bookmark_list_of_dictionaries = [
            bookmark.to_dict() for bookmark in bookmarks
        ]
        return Response(json.dumps(bookmark_list_of_dictionaries), mimetype="application/json", status=200)


    @flask_jwt_extended.jwt_required()
    @is_valid_int
    @is_valid_id
    @handle_db_insert_error
    @secure_bookmark
    def post(self):
        body = request.get_json()
        post_id = body.get('post_id')
        post = Post.query.get(post_id)
        if post == None:
             # throw 404
             invalid_id = {
                 'Invalid id: {0}'.format(post_id)
             }
             return Response(json.dumps(invalid_id), mimetype="application/json", status=404)
        bookmark = Bookmark(self.current_user.id, post_id)
        db.session.add(bookmark)
        db.session.commit()
        return Response(json.dumps(bookmark.to_dict()), mimetype="application/json", status=201)

class BookmarkDetailEndpoint(Resource):

    def __init__(self, current_user):
        self.current_user = current_user
    
    @flask_jwt_extended.jwt_required()
    @is_valid_int_delete
    @is_valid_id_delete
    @check_ownership_of_bookmark
    def delete(self, id):
        # bookmark = Bookmark.query.get(id)
        Bookmark.query.filter_by(id=id).delete()
        db.session.commit()
        serialized_data = {
            'message': 'Bookmark {0} successfully deleted.'.format(id)
        }
        return Response(json.dumps(serialized_data), mimetype="application/json", status=200)



def initialize_routes(api):
    api.add_resource(
        BookmarksListEndpoint, 
        '/api/bookmarks', 
        '/api/bookmarks/', 
        resource_class_kwargs={'current_user': flask_jwt_extended.current_user}
    )

    api.add_resource(
        BookmarkDetailEndpoint, 
        '/api/bookmarks/<id>', 
        '/api/bookmarks/<id>',
        resource_class_kwargs={'current_user': flask_jwt_extended.current_user}
    )
